//
//  Week1DemoApp.swift
//  Week1Demo
//
//  Created by SFSU on 8/22/23.
//

import SwiftUI

@main
struct Week1DemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
